﻿using Azure.Messaging.ServiceBus;

internal class Publisher
{
    private const string connectionString = "Endpoint=sb://sb-eda-test.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=B89to36aM1FiU+0VvPGOJfWtrZndqurbz+ASbMeLJ9k=";
    private const string topicName = "ventas";

    private static async Task Main()
    {
        await EnviarMensaje("Notifación para todos", "all");
        await EnviarMensaje("Notifación solo NORUEGA", "norway");
        await EnviarMensaje("Notifación solo DINAMARCA", "denmark");
        await EnviarMensaje("Notifación entidades NORTE", "north");
    }

    private static async Task EnviarMensaje(string contenido, string destino)
    {
        await using var client = new ServiceBusClient(connectionString);
        ServiceBusSender sender = client.CreateSender(topicName);

        ServiceBusMessage message = new ServiceBusMessage(contenido);
        message.ApplicationProperties.Add("destiny", destino);

        await sender.SendMessageAsync(message);
        Console.WriteLine($"📨 Mensaje enviado: '{contenido}' para {destino}");
    }
}