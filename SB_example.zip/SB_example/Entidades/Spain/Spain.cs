﻿using Azure.Messaging.ServiceBus;

namespace Spain
{
    public class Spain
    {
        private const string connectionString = "Endpoint=sb://sb-eda-test.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=B89to36aM1FiU+0VvPGOJfWtrZndqurbz+ASbMeLJ9k=";
        private const string topicName = "ventas";
        private const string subscriptionName = "spain";

        private static async Task Main()
        {
            await using var client = new ServiceBusClient(connectionString);
            ServiceBusReceiver receiver = client.CreateReceiver(topicName, subscriptionName);

            Console.WriteLine("ESPAÑA Escuchando mensajes...");
            while (true)
            {
                var message = await receiver.ReceiveMessageAsync();
                if (message != null)
                {
                    Console.WriteLine($"📥 España recibió: {message.Body}");
                    await receiver.CompleteMessageAsync(message);
                }
            }
        }
    }
}